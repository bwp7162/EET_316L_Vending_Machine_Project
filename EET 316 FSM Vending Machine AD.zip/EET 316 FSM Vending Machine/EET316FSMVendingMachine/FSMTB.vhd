--------------------------------------------------------------------------------
-- Company: 
-- Engineer:
--
-- Create Date:   10:43:12 05/04/2022
-- Design Name:   
-- Module Name:   C:/Users/LU244/Desktop/EET 316 FSM Vending Machine/EET316FSMVendingMachine/FSMTB.vhd
-- Project Name:  EET316FSMVendingMachine
-- Target Device:  
-- Tool versions:  
-- Description:   
-- 
-- VHDL Test Bench Created by ISE for module: VendingMachine
-- 
-- Dependencies:
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
--
-- Notes: 
-- This testbench has been automatically generated using types std_logic and
-- std_logic_vector for the ports of the unit under test.  Xilinx recommends
-- that these types always be used for the top-level I/O of a design in order
-- to guarantee that the testbench will bind correctly to the post-implementation 
-- simulation model.
--------------------------------------------------------------------------------
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--USE ieee.numeric_std.ALL;
 
ENTITY FSMTB IS
END FSMTB;
 
ARCHITECTURE behavior OF FSMTB IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT VendingMachine
    PORT(
         nickel_in : IN  std_logic;
         dime_in : IN  std_logic;
         quarter_in : IN  std_logic;
         clk : IN  std_logic;
         reset : IN  std_logic;
         clkout : OUT  std_logic;
         candy_out : OUT  std_logic;
         nickel_out : OUT  std_logic;
         dime_out : OUT  std_logic
        );
    END COMPONENT;
    

   --Inputs
   signal nickel_in : std_logic := '0';
   signal dime_in : std_logic := '0';
   signal quarter_in : std_logic := '0';
   signal clk : std_logic := '0';
   signal reset : std_logic := '1';

 	--Outputs
   signal clkout : std_logic;
   signal candy_out : std_logic;
   signal nickel_out : std_logic;
   signal dime_out : std_logic;

   -- Clock period definitions
   constant clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: VendingMachine PORT MAP (
          nickel_in => nickel_in,
          dime_in => dime_in,
          quarter_in => quarter_in,
          clk => clk,
          reset => reset,
          clkout => clkout,
          candy_out => candy_out,
          nickel_out => nickel_out,
          dime_out => dime_out
        );

   -- Clock process definitions
   clk_process :process
   begin
		clk <= '0';
		wait for clk_period/2;
		clk <= '1';
		wait for clk_period/2;
   end process;
 
	reset_process :process
	begin
		wait for clk_period;
		reset <= '0';
		wait for clk_period * 12;
	end process;
	
	nickel_process :process
	begin
		wait for clk_period * 2;
		nickel_in <= '1';
		wait for clk_period * 2;
		nickel_in <= '0';
		wait for clk_period;
	end process;
	
	dime_process :process
	begin
		wait for clk_period * 2;
		dime_in <= '1';
		wait for clk_period * 2;
		dime_in <= '0';
		wait for clk_period * 4;
	end process;
	
	quarter_process :process
	begin
		wait for clk_period;
		quarter_in <= '1';
		wait for clk_period * 3;
		quarter_in <= '0';
	end process;
	
	
	



END;
