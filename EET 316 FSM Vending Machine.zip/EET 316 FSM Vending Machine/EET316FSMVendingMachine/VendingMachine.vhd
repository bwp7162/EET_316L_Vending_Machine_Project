----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    09:47:19 05/04/2022 
-- Design Name: 
-- Module Name:    VendingMachine - FSM 
-- Project Name: 
-- Target Devices: 
-- Tool versions: 
-- Description: 
--
-- Dependencies: 
--
-- Revision: 
-- Revision 0.01 - File Created
-- Additional Comments: 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
USE ieee.std_logic_unsigned.all;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx primitives in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity VendingMachine is
    Port ( nickel_in : in  STD_LOGIC;
           dime_in : in  STD_LOGIC;
           quarter_in : in  STD_LOGIC;
           clk : in  STD_LOGIC;
           reset : in  STD_LOGIC;
			  clkout : out STD_LOGIC;
           candy_out : out  STD_LOGIC;
           nickel_out : out  STD_LOGIC;
           dime_out : out  STD_LOGIC);
end VendingMachine;

architecture FSM of VendingMachine is
SIGNAL Count: STD_LOGIC_VECTOR (26 downto 0);
SIGNAL clkoutFSM: STD_LOGIC;
type state_type is (st0, st5, st10, st15, st20, st25, st30, st35, st40, st45);
signal current_state, next_state: state_type;
begin

--slow clock
PROCESS (clk, reset)
BEGIN 
IF reset='1' then 
Count<="000000000000000000000000000";                      
ELSIF clk'EVENT AND clk='1' THEN 
Count<=Count+1; 
END IF;
END PROCESS;
clkout<=Count(1);
clkoutFSM <= Count(1);


--next state decoder
process (current_state, nickel_in, dime_in, quarter_in)
begin
case current_state is 
when st0 =>
if nickel_in = '1' then next_state <= st5;
elsif dime_in = '1' then next_state <= st10;
elsif quarter_in = '1' then next_state <= st25;
else next_state <= st0;
end if;
when st5 =>
if nickel_in = '1' then next_state <= st10;
elsif dime_in = '1' then next_state <= st15;
elsif quarter_in = '1' then next_state <= st30;
else next_state <= st5;
end if;
when st10 =>
if nickel_in = '1' then next_state <= st15;
elsif dime_in = '1' then next_state <= st20;
elsif quarter_in = '1' then next_state <= st35;
else next_state <= st10;
end if;
when st15 =>
if nickel_in = '1' then next_state <= st20;
elsif dime_in = '1' then next_state <= st25;
elsif quarter_in = '1' then next_state <= st40;
else next_state <= st15;
end if;
when st20 =>
if nickel_in = '1' then next_state <= st25;
elsif dime_in = '1' then next_state <= st30;
elsif quarter_in = '1' then next_state <= st45;
else next_state <= st20;
end if;
when st25 =>
next_state <= st0;
when st30 =>
next_state <= st0;
when st35 =>
next_state <= st0;
when st40 =>
next_state <= st35;
when st45 =>
next_state <= st35;
when OTHERS =>
next_state <= st0;
end case;
end process;


--state memory
process (clkoutFSM, reset)
begin
if reset = '1' then
current_state <= st0;
elsif clkoutFSM'event and clkoutFSM = '1' then
current_state <= next_state;
end if;
end process;


--output decoder
process (current_state)
begin
case current_state is
when st25 =>
candy_out <= '1';
nickel_out <= '0';
dime_out <= '0';
when st30 =>
candy_out <= '1';
nickel_out <= '1';
dime_out <= '0';
when st35 =>
candy_out <= '1';
dime_out <= '1';
nickel_out <= '0';
when st40 =>
nickel_out <= '1';
candy_out <= '0';
dime_out <= '0';
when st45 =>
dime_out <= '1';
candy_out <= '0';
nickel_out <= '0';
when OTHERS =>
candy_out <= '0';
nickel_out <= '0';
dime_out <= '0';
end case;
end process;


end FSM;

